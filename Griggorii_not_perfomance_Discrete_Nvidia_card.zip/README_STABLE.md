                  stable in wayland not lag browser multi card gpu/cpu

Not testing gpu nvidia not card my home , intel not perfomance

sudo cp 20-intel.conf /usr/share/X11/xorg.conf.d/



