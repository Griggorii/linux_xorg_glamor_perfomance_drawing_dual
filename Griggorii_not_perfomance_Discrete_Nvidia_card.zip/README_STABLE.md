                  stable in wayland not lag browser multi card gpu/cpu not perfomance glamor! just config

Not testing gpu nvidia not card my home , intel not perfomance

sudo cp 20-intel.conf /usr/share/X11/xorg.conf.d/

test V2

sudo mv V2.conf /usr/share/X11/xorg.conf.d/20-intel.conf



